package com.application.tastyapp.response.onClick

import com.application.tastyapp.response.model.frontScreen.ItemX

interface onClickListener {

    fun onClickOfView(itemX: ItemX)
}