package com.application.tastyapp.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.application.tastyapp.R
import com.application.tastyapp.adaptor.TastyAdaptor
import com.application.tastyapp.databinding.FragmentMainScreenBinding
import com.application.tastyapp.response.model.frontScreen.Item
import com.application.tastyapp.response.model.frontScreen.ItemX
import com.application.tastyapp.response.model.frontScreen.ResultModel
import com.application.tastyapp.response.module.Status
import com.application.tastyapp.viewModel.TastyViewModel
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MainScreenFragment : Fragment() {

    private var list = emptyList<ResultModel>()
    lateinit var mainScreenBinding: FragmentMainScreenBinding
    lateinit var tastyViewModel: TastyViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        mainScreenBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_main_screen, container, false)
        return mainScreenBinding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tastyViewModel = ViewModelProviders.of(this).get(TastyViewModel::class.java)
        loadData()
    }

    private fun loadData() {
        tastyViewModel.getData().observe(viewLifecycleOwner, {
            when (it.status) {
                Status.SUCCESS -> {
                    val adaptor = TastyAdaptor(it.data?.items!! as ArrayList<ResultModel>)
                    val layoutManager = LinearLayoutManager(context)
                    mainScreenBinding.mainRecyclerView.adapter = adaptor
                    mainScreenBinding.mainRecyclerView.layoutManager = layoutManager
                }
            }
        })
    }
}