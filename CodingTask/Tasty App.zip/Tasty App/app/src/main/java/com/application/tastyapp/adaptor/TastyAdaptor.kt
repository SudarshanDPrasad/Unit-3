package com.application.tastyapp.adaptor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.application.tastyapp.R
import com.application.tastyapp.databinding.MainscreenItemLayoutBinding
import com.application.tastyapp.response.model.frontScreen.Item
import com.application.tastyapp.response.model.frontScreen.ItemX
import com.application.tastyapp.response.model.frontScreen.ResultModel
import com.bumptech.glide.Glide

class TastyAdaptor(
    private val listOfResponse: List<ResultModel>,
) : RecyclerView.Adapter<TastyHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TastyHolder {
        val itemLayoutBinding: MainscreenItemLayoutBinding =
            DataBindingUtil.inflate(LayoutInflater.from(parent.context),
                R.layout.mainscreen_item_layout, parent, false)

        return TastyHolder(itemLayoutBinding)
    }

    override fun onBindViewHolder(holder: TastyHolder, position: Int) {
        val responseList = listOfResponse[position]

        holder.setData(responseList)
    }

    override fun getItemCount(): Int {
        return listOfResponse.size
    }
}

class TastyHolder(
    val itemLayoutBinding: MainscreenItemLayoutBinding,
) : RecyclerView.ViewHolder(itemLayoutBinding.root) {

    fun setData(resultModel: ResultModel) {
        Glide.with(itemLayoutBinding.ivMainLayout).load(resultModel.item.thumbnailUrl)
            .into(itemLayoutBinding.ivMainLayout)
        itemLayoutBinding.TvNameOfMainLayout.text = resultModel.item.name
    }
}
